﻿# MCP Replay Baselines

This directory stores canonical replay runs for regression checks. Use 
python -m scripts.mcp_replay --requests tests/scenarios/query_runs.json --baseline reports/baselines/mcp_run-20251109-143546.jsonl 
to compare current search quality against this snapshot.

