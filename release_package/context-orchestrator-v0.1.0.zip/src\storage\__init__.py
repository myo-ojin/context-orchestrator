"""Storage adapters for vector DB and BM25 index"""
