"""Core services for ingestion, search, and consolidation"""
