#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
End-to-end test suite for Context Orchestrator
"""
