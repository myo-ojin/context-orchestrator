Context Orchestrator v0.1.0 OSS bundle
Generated: 2025-11-15 19:04:00Z

Included top-level entries:
- reports
- scripts
- src
- tests
- .gitignore
- CHANGELOG.md
- config.yaml.template
- CONTRIBUTING.md
- LICENSE
- OSS_FILE_CHECKLIST.md
- OSS_RELEASE_SUMMARY.md
- pyproject.toml
- QUICKSTART.md
- README.md
- README_internal.md
- README_JA.md
- requirements.txt
- setup.py
