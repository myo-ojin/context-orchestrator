"""Unit tests for MCP protocol handler"""
