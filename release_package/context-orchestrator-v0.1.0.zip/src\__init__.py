"""
Context Orchestrator - External Brain System (外部脳システム)

A Model Context Protocol (MCP) server that captures, organizes, and retrieves
developer experiences across any LLM client.
"""

__version__ = "0.1.0"
